# DBMS 네트워크 접속 진단 통신 시스템

직접 구현한 TCP 진단 서버가 최대 세 MariaDB를 병렬 점검하고, 웹 클라이언트가 DB별 상태와 근거를 표시합니다.

## 제출본 빠른 실행

상위 폴더의 `01_프로그램_실행.cmd`를 실행하세요. Python 3.14.3 이상이 필요합니다. DEMO는 표준 라이브러리만 사용하며 MariaDB 설치가 필요하지 않습니다. DB 3개 혼합 상태에서 각 카드를 클릭하면 선택한 DB의 위쪽 상태·색상·상세 설명이 바뀝니다. 전체 상태는 별도로 유지됩니다.

상위 `02_결과비교/`의 BAT 세 개는 정상·지연 경고·접속 실패 DEMO를 각각 자동 실행합니다. 실제 TCP로 요청·응답하지만 DB 결과는 모의 데이터입니다.

## 구조

브라우저 → HTTP 웹/TCP 클라이언트 → TCP 진단 서버 → 실제 MariaDB 또는 DEMO 모의 상태

주요 코드: `app/server.py`, `client_core.py`, `db_targets.py`, `db_probe.py`, `feedback.py`, `protocol.py`, `web_client.py`, `static/`.
`start_demo.py`는 제출용 실행 도구로, 기존 서버와 웹 클라이언트를 함께 시작합니다. 비어 있는 로컬 포트를 사용하고 화면을 DEMO로 초기화합니다. 기존 프로그램을 종료하지 않습니다.

## LIVE 실행

```powershell
python -m pip install -r requirements.txt
```

실행 중인 MariaDB와 진단 계정을 준비하고 진단 서버를 띄울 터미널에서 설정합니다. 아래 값은 실제 환경에 맞춥니다.

```powershell
$env:DB_HOST = '127.0.0.1'
$env:DB_PORT = '3307'
$env:DB_USER = 'course_monitor'
$env:DB_NAME = 'course_network_demo'
$env:DB_PASSWORD = [System.Net.NetworkCredential]::new('', (Read-Host 'DB 암호' -AsSecureString)).Password
python -B -m app.server --host 127.0.0.1 --port 62036
```

두 번째 터미널에서 웹 클라이언트를 실행합니다.

```powershell
python -B -m app.web_client --host 127.0.0.1 --port 62039
```

`http://127.0.0.1:62039/`에서 진단 서버 `127.0.0.1:62036`, LIVE를 선택합니다. DB 2·3은 서버 시작 전에 `DB2_`, `DB3_` 접두사로 HOST·PORT·USER·PASSWORD·NAME을 설정합니다. 설정 변경 후 서버를 다시 실행합니다. 연결·인증·SELECT 1을 확인하며, 경고 기준은 기본 500ms 초과입니다. DB 연결·읽기·쓰기 제한은 각각 3초입니다.

`scripts/install_local_course.ps1`은 별도의 단일 MariaDB 설치 도구이며 DB 3개를 자동 설치하지 않습니다. 실제 DB 암호·데이터 폴더는 제출본에 넣지 않습니다. 제출용 DEMO 바로가기는 실제 DB 환경변수를 이어받지 않으므로 LIVE는 위 수동 실행 절차로 준비합니다.

## 검증 자료와 테스트

- [검증 요약](../05_검증자료/FINAL_VALIDATION.md)
- [개별 Python 테스트 결과](../05_검증자료/unittest-20261121.txt)
- [최종 실행 증빙](../05_검증자료/최종_실행_증빙/)
- [노트북·LAN 준비 안내](docs/LAPTOP_LAN_TEST.md)

```powershell
python -B -m unittest discover -s tests -v
python -B start_demo.py --self-test
```

프런트엔드 회귀 검사는 Node.js가 있는 개발 환경에서 실행합니다. Node.js는 프로그램 실행에 필요하지 않습니다.

```text
node --test tests/test_target_selection.cjs
```

루트 PCAPNG 두 개는 기존 패킷 분석 테스트의 입력이므로 유지합니다. 최신 캡처는 상위 검증자료 폴더를 참고합니다. 최종 캡처는 루프백이며 물리 LAN의 1·2계층 검증과 구분합니다.
