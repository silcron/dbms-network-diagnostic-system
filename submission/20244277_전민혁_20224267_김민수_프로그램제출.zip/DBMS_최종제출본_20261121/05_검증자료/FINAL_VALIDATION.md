# 제출본 검증 기록

## 2026-11-21 실행 및 회귀 검사

- Python 3.14.7에서 `python -B -m unittest discover -s tests -v` 실행: **131개 성공**, 실패·오류·건너뜀 0개, 61.305초.
- [개별 테스트 결과](unittest-20261121.txt)
- `node --test tests/test_target_selection.cjs`: 프런트엔드 검사 **3개 성공**. 실제 DB 카드 클릭 처리 함수를 실행해 위쪽 상태·색상·선택 표시·상세 설명 전환과 전체 상태 보존을 확인했다. Node.js는 개발 검사에만 사용하며 프로그램 실행에 필요하지 않다.
- 기본 CMD: 실제 HTTP/TCP 통신으로 DEMO 혼합 상태 NORMAL·WARNING·DOWN 및 OSI 정보 7개 반환.
- BAT 3개: 정상 NORMAL / 지연 경고 WARNING / 접속 실패 DOWN을 각각 반환.
- 기본 포트 둘을 사용 중으로 만든 경우 빈 포트로 전환했고 기존 수신 소켓은 유지됐다.
- 위 네 실행 도구와 포트 충돌 검사를 한글·공백 경로에서도 반복해 통과했다.
- 실행 도구 종료 후 사용한 웹·진단 서버 포트가 닫히는 것을 확인했다.
- 제출본은 Python 표준 라이브러리 기반 DEMO 실행을 기본으로 한다. 실제 DB 접속 정보는 이어받지 않으며 LIVE는 별도 설정이 필요하다.

## 최종 LIVE 원본 자료: 2026-11-14

[최종 실행 증빙](최종_실행_증빙/)의 원본은 한 PC의 루프백에서 실제 MariaDB 3개를 점검한 당시 자료다. 이번 제출 도구의 DEMO 실행과 날짜·모드를 구분한다.

- DB 1 NORMAL: 로그인·SELECT 1 성공, 총 50.39ms
- DB 2 WARNING: 인증 거부 1045, 총 49.99ms
- DB 3 DOWN: 연결 실패 2003, 총 2,057.53ms
- 대표 전체 상태 DOWN, 클라이언트 왕복 시간 2,066.14ms
- 세 DB 정상 상태 확인 후 DB 2의 임시 계정 암호를 변경하고 DB 3을 중지해 재현했다.
- [ports.json](최종_실행_증빙/ports.json), [results.json](최종_실행_증빙/results.json), [응답 대조](최종_실행_증빙/response-check.json)를 함께 보관한다.

## 패킷 근거와 실험 범위

[final-run.pcapng](최종_실행_증빙/final-run.pcapng)는 132개 패킷이며 NULL/Loopback 형식이다.

- 진단 LIVE stream 0: 1·2·3번 SYN → SYN/ACK → ACK
- DB 1 stream 1: 10·12·15번 TCP 연결 수립
- DB 3의 첫 시도: 16번 SYN, 17번 RST/ACK
- 104번 LIVE 결과, 121·123번 DEMO 혼합 요청·응답
- 진단 DEMO stream 8의 연결 수립: 114·115·116번
- 2026-11-16 TShark 4.6.8 재검증에서 Seq/Ack와 응용 응답을 확인했다. DB 1 통신에서 TLS 1.3을 확인했으며 암호화된 SQL 내용을 직접 읽었다고 서술하지 않는다.
- HTTP 구간은 캡처 범위 밖이며 물리 LAN의 케이블·Ethernet MAC 검증은 미실시다.

카드 선택은 저장된 같은 진단 응답의 상세 대상을 바꾸는 조작이다. 위쪽 상태도 선택한 DB에 맞춰 바뀌지만 전체 상태와 요청 왕복 시간은 별도로 유지된다.
